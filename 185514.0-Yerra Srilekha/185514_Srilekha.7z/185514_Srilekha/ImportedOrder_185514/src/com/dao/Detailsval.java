package com.dao;

import java.util.ArrayList;

import com.bean.Order;


public class Detailsval 
{
	public void saveOrder(Order bean)
	{
		
		ArrayList<Order> a=new ArrayList<Order>();
		a.add(bean);
		System.out.println(a);
		
	}
}
