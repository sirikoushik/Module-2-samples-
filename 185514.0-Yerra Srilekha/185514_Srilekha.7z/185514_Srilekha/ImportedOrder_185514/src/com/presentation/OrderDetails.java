package com.presentation;

import java.util.Random;
import java.util.Scanner;

import com.bean.Order;

import com.service.Orderplace;

public class OrderDetails 
{
	
	static Scanner s=new Scanner(System.in);
	public static void main(String[] args)
	{
		Random r=new Random();
		Orderplace robj=new Orderplace();
		Order bean=new Order();
		int id;
		id=(int) r.nextInt(100);
		bean.setId(id);
		while(true) {
			System.out.println("Enter the Quantity");
			int quantity=s.nextInt();
			boolean isValid=robj.checkQuantity(quantity);
			if(isValid)
				bean.setQuantity(quantity);
				break;
			} 
	    	System.out.println("Enter the price");
	    	double price = s.nextDouble();
	    	bean.setPrice(price);
	    	robj.comDataLayer(bean);
	    	double charges=robj.calculateOrder(bean);
	    	bean.setCharges(charges);
	    	double amount=robj.CalculateTotalAmnt(bean);
	    	bean.setAmount(amount);
	    	System.out.println("Amount is"+amount);
	    	System.out.println("Charges is"+charges);
	}
	

}


