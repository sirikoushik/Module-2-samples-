package com.service;

import com.bean.Order;
import com.dao.Detailsval;
import com.presentation.OrderDetails;

public class Orderplace 
{
	Order o=new Order();
	OrderDetails od=new OrderDetails();
	Detailsval dobj=new Detailsval();
	public void comDataLayer(Order bean)
	{
		dobj.saveOrder(bean);
	}
	
	public double calculateOrder(Order bean) 
	{
		double amount=0;
		amount=(int)(bean.getPrice()*75);
		return amount;
	}
	public double CalculateTotalAmnt(Order bean)
	{
		double total=0;
		double conv=(1.25/100)*o.getCharges();
		total=o.getQuantity()*conv;
		o.setAmount(total);
		return total;
	}
	public boolean checkQuantity(int quantity)
	{
		try {
			if(quantity>1)
			{
				return true;
			}
			else 
				throw new Exception("Enter correct quantity");
			}catch(Exception e)
		{
				System.out.println(e);
		}
		return false;
		// TODO Auto-generated method stub
		
	}
	
}
