package com.service;

import com.bean.Order;

public interface OrderRepo 
{
	int calculateOrder(Order bean);
	public boolean checkQuantity(int quantity);

}
