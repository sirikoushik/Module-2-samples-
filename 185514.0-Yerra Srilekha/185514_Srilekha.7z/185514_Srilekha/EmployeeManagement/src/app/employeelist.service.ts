import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable} from 'rxjs';
import { IEmployee } from './iemployee';


@Injectable({
  providedIn: 'root'
})
export class EmployeelistService {
  employee:IEmployee[]=[];

  constructor(private http:HttpClient) { }

getEmployee():Observable<IEmployee[]>
 {
return  this.http.get<IEmployee[]>('../assets/employee.json');
}
addEmployee(emp:IEmployee)
{
   console.log("Hello " + emp.Id);
  this.employee.push(emp);

}
get(){
  return this.employee;
}
}