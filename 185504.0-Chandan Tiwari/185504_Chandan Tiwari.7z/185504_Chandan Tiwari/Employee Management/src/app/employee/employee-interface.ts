//Telling how the data should be taken in employee.json
export interface EmployeeInterface {
    empId:number;
    empName:string;
    empEmail:string;
    empPhone:number;
}
