import { Component, OnInit } from '@angular/core';
import { EmployeeInterface } from './employee-interface';
import { EmployeeServiceService } from './employee-service.service';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent implements OnInit {
  employees:EmployeeInterface[];
  empId:number;
  empName:string;
  empEmail:string;
  empPhone:number;

  constructor(private _empservice:EmployeeServiceService) { }

  ngOnInit() {
    this.getEmployees(); //details of employees
  }
  onDelete(emp:EmployeeInterface){
    this._empservice.onDelete(emp); //deleting the employee
  }

  onUpdate(emp:EmployeeInterface){
    this._empservice.onUpdateData(emp);
  }

  getEmployees(){
    //adding employees or getting data of employees
    if(!this._empservice.getData())
    {
      this._empservice.getEmployees().subscribe((data)=>{this.employees=data;
      this._empservice.setData(this.employees);
      },(error)=>console.log(error));
    }
    else
    {
      this.employees=this._empservice.getData();
    }
  }

}
