import { Injectable } from '@angular/core';
import { EmployeeInterface } from './employee-interface';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from '../../../node_modules/rxjs';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})

export class EmployeeServiceService {

  employees: EmployeeInterface[];
  constructor(private httpclient: HttpClient) {
  }
  getEmployees(): Observable<EmployeeInterface[]> {
    return this.httpclient.get<EmployeeInterface[]>("./assets/employee.json").pipe(catchError(this.handleError));
    //getting data from json
  }
  setData(employee: EmployeeInterface[]) {
    this.employees = employee; //setting data
  }
  getData() {
    return this.employees; //getting the data which is set
  }
  onDelete(employee: EmployeeInterface) {
    //deleting the data
    let index = this.employees.indexOf(employee);
    this.employees.splice(index, 1);
  }
  onUpdateData(employee: EmployeeInterface){
    this.employees[this.employees.indexOf(employee)].empId = employee.empId;
    this.employees[this.employees.indexOf(employee)].empName = employee.empName;
    this.employees[this.employees.indexOf(employee)].empEmail = employee.empEmail;
    this.employees[this.employees.indexOf(employee)].empPhone = employee.empPhone;
  }
  addEmployee(employees: EmployeeInterface) {
    //adding employee
    this.employees.push(employees);
  }
  handleError(errorResponse: HttpErrorResponse) {
    //Handling Errors
    if (errorResponse.error instanceof ErrorEvent) {
      console.log("Client Side error", errorResponse.error.message);
    }
    else {
      console.log("Server side error ", errorResponse);
    }
    return throwError("Something went wrong, please try again after sometime");
  }

}
