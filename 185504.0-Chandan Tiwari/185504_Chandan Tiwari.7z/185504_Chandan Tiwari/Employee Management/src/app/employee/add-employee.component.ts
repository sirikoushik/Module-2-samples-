import { Component, OnInit } from '@angular/core';
import { EmployeeServiceService } from './employee-service.service';
import { EmployeeInterface } from './employee-interface';
import {Router} from '@angular/router'

@Component({
  selector: 'app-add-employee',
  templateUrl: './add-employee.component.html',
  styleUrls: ['./add-employee.component.css']
})
export class AddEmployeeComponent implements OnInit {

  constructor(private empservice:EmployeeServiceService,private router:Router) { }
  employees:EmployeeInterface[];
  empId:number;
  empName:string;
  empEmail:string;
  empPhone:number;

  ngOnInit() {
    if(!this.empservice.getData())
    {
      this.empservice.getEmployees().subscribe((data)=>{this.employees=data;
      this.empservice.setData(this.employees);
      },(error)=>console.log(error));
    }
  }
  onSubmit(form:EmployeeInterface){
    this.empservice.addEmployee(form);
    this.router.navigate(['/listEmployees']);
  }

}
