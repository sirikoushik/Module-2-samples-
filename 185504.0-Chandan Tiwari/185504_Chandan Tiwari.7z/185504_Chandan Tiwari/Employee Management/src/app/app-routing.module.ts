import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EmployeeListComponent } from './employee/employee-list.component';
import { AddEmployeeComponent } from './employee/add-employee.component';
import { UpdateEmployeeComponent } from './update-employee/update-employee.component';

const routes: Routes = [
  /* Routing paths */
  {path : 'listEmployees',component:EmployeeListComponent},
  {path : 'addEmployees',component:AddEmployeeComponent},
  {path : 'updateEmployee', component:UpdateEmployeeComponent}, 
  {path :'', redirectTo:'/listEmployees', pathMatch:'full'},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
