/*
* Purpose : This interface represents the schema of what type of data to be stored
	 */
export interface Products{
    id:String;
    name:String;
    price:number;
    category:String;
}