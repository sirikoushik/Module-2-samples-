import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Employee } from './Employee';

@Injectable({
  providedIn: 'root'
})
export class EmployeeServiceService {

  constructor(private httpClient: HttpClient) {

    this.getBookDetails().subscribe(data => this.bookList = data);
  }

  bookList: Array<Employee> = [];

  url: string = "/assets/book.json";


  getBookDetails(): any {
    return this.httpClient.get<Employee>(this.url);
  }//taking data from Json File


  deleteBook(id: number): void {
    let i = 0;
    for (let emp of this.bookList) {
      if (emp.id == id) {
        console.log("Employee id " + emp.id);
        console.log(this.bookList.splice(i, 1));
      }
      i++;
    }

  }

  setBookDetails(book: Employee) {
    this.bookList.push(book);


  }




  updateBookDetails(book: Employee) {
    for (let b of this.bookList) {
      if (book.id == b.id) {
        b.id = book.id;
        b.email = book.email;
        b.phone = book.phone;
        b.name = book.name;
      }
    }
    console.log(this.bookList);
  }
  bookList1: Array<Employee>
  search(data):any[]{
    this.bookList1=[]

    for (let book of this.bookList) {
      
      if (book.phone == data.genre1) {
        this.bookList1.push(book)
        
  }
} 
return (this.bookList1)
}
search1(data):any[]{
  this.bookList1=[]

  for (let book of this.bookList) {
    if (book.id == data.code) {
     
      this.bookList1.push(book)
      
}
}
return (this.bookList1)
}
}

