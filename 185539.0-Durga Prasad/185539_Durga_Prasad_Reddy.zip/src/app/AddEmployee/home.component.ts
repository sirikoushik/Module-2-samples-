import { Component, OnInit } from '@angular/core';
import { EmployeeServiceService } from '../employee-service.service';
import { Employee } from '../Employee';
import {Router} from '@angular/router';



@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  [x: string]: any;

  bookList: any[];
  book: Employee = new Employee();

  constructor(private bookService: EmployeeServiceService) {
    this.bookService.getBookDetails().subscribe(data => this.bookList = data);
  }

  ngOnInit() {
  }


  onSubmit() {
    this.router.navigateByUrl('/emplist');
}

  insert(data) {
    alert(`Employee Added`);
    this.book.id = data.id;
    this.book.name = data.name;
    this.book.email = data.email;
    this.book.phone = data.phone;
    console.log(this.book);
    this.bookService.setBookDetails(this.book);
    this.Routes.navigate(["/emplist"]);

  }

}
