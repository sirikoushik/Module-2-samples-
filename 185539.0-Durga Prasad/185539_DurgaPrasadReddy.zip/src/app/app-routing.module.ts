import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './AddEmployee/home.component';
import { AboutComponent } from './ListAllEmployees/about.component';



const routes: Routes = [
  {path:'addemp', component: HomeComponent},
  {path:'emplist', component: AboutComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
