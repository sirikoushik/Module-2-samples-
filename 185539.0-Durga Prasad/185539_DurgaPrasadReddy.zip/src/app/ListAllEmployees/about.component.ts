import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { NgForm } from '@angular/forms';
import { EmployeeServiceService } from '../employee-service.service';
import { Employee } from '../Employee';

@Component({
  selector: 'app-about',
  templateUrl: './about.component.html',
  styleUrls: ['./about.component.css']
})
export class AboutComponent implements OnInit {

  bookList: any = [];
  constructor(private bookService: EmployeeServiceService) {
    this.bookList = this.bookService.bookList;

  }

  ngOnInit() {
    this.bookList = this.bookService.bookList;

  }
  reload() {
    this.bookList = this.bookService.bookList;
  }

  flag = false;
  name; id; email; phone;

  bo: Employee = new Employee;
  changeFlag(b: Employee) {
    this.flag = true;
    this.name = b.name; this.id = b.id; this.email = b.email; this.phone = b.phone;


  }
  update
    (f) {
    let b: Employee = new Employee;
    b = f;
    console.log(b);
    this.bookService.updateBookDetails(b);
  }

  delete(code: number) {
    this.bookService.deleteBook(code);
    this.bookList = this.bookService.bookList;
  }
}
